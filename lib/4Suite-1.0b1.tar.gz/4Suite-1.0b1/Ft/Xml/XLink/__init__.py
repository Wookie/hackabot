########################################################################
# $Header: /var/local/cvsroot/4Suite/Ft/Xml/XLink/__init__.py,v 1.9 2005/02/25 06:32:17 mbrown Exp $
"""
XLink processing package

See http://www.w3.org/TR/xlink/

Copyright 2005 Fourthought, Inc. (USA).
Detailed license and copyright information: http://4suite.org/COPYRIGHT
Project home, documentation, distributions: http://4suite.org/
"""

XLINK_NAMESPACE = u'http://www.w3.org/1999/xlink'
