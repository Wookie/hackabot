########################################################################
# $Header: /var/local/cvsroot/4Suite/Ft/Xml/Sax.py,v 1.3 2005/03/20 03:54:40 jkloth Exp $
"""
Abstraction module for Domlette SAX usage.

Copyright 2005 Fourthought, Inc. (USA).
Detailed license and copyright information: http://4suite.org/COPYRIGHT
Project home, documentation, distributions: http://4suite.org/
"""

from Ft.Xml.cDomlettec import CreateParser

# 4Suite-specific SAX features
from Ft.Xml.cDomlettec import FEATURE_PROCESS_XINCLUDES

# 4Suite-specific SAX properties
from Ft.Xml.cDomlettec import PROPERTY_WHITESPACE_RULES


class ContentHandler:
    """Interface for receiving logical document content events.

    This is the main callback interface for the Parser. The order of
    events in this interface mirrors the order of the information in the
    document."""

    def setDocumentLocator(self, locator):
        """Called by the parser to give the application a locator for
        locating the origin of document events.

        The locator allows the application to determine the end
        position of any document-related event, even if the parser is
        not reporting an error. Typically, the application will use
        this information for reporting its own errors (such as
        character content that does not match an application's
        business rules). The information returned by the locator is
        probably not sufficient for use with a search engine.

        Note that the locator will return correct information only
        during the invocation of the events in this interface. The
        application should not attempt to use it at any other time."""

    def startDocument(self):
        """Receive notification of the beginning of a document.

        The parser will invoke this method only once, before any
        other methods in this interface."""

    def endDocument(self):
        """Receive notification of the end of a document.

        The parser will invoke this method only once, and it will
        be the last method invoked during the parse. The parser shall
        not invoke this method until it has either abandoned parsing
        (because of an unrecoverable error) or reached the end of
        input."""

    def startPrefixMapping(self, prefix, uri):
        """Begin the scope of a prefix-URI Namespace mapping.

        The information from this event is not necessary for normal
        Namespace processing: the XmlParser will automatically replace
        prefixes for element and attribute names.

        There are cases, however, when applications need to use
        prefixes in character data or in attribute values, where they
        cannot safely be expanded automatically; the
        start/endPrefixMapping event supplies the information to the
        application to expand prefixes in those contexts itself, if
        necessary.

        Note that start/endPrefixMapping events are not guaranteed to
        be properly nested relative to each-other: all
        startPrefixMapping events will occur before the corresponding
        startElementNS event, and all endPrefixMapping events will occur
        after the corresponding endElementNS event, but their order is
        not guaranteed."""

    def endPrefixMapping(self, prefix):
        """End the scope of a prefix-URI mapping.

        See startPrefixMapping for details. This event will always
        occur after the corresponding endElementNS event, but the order
        of endPrefixMapping events is not otherwise guaranteed."""

    def startElementNS(self, (uri, localName), qualifiedName, atts):
        """Signals the start of an element.

        The uri parameter is None for elements which have no namespace,
        the qualifiedName parameter is the raw XML name used in the source
        document, and the atts parameter holds an instance of the
        Attributes class containing the attributes of the element.
        """

    def endElementNS(self, (uri, localName), qualifiedName):
        """Signals the end of an element.

        The uri parameter is None for elements which have no namespace,
        the qualifiedName parameter is the raw XML name used in the source
        document."""

    def characters(self, content):
        """Receive notification of character data.

        The parser will call this method to report each chunk of
        character data.   The parser will return all contiguous
        character data in a single chunk."""


class Locator:
    """Interface for associating a parse event with a document
    location. A locator object will return valid results only during
    calls to ContentHandler methods; at any other time, the results are
    unpredictable."""

    def getColumnNumber(self):
        """Return the column number where the current event ends."""

    def getLineNumber(self):
        """Return the line number where the current event ends."""

    def getSystemId(self):
        """Return the system identifier for the current event."""


class Attributes:
    """Interface for a set of XML attributes.

    Contains a set of XML attributes, accessible by expanded name."""

    def getValue(self, name):
        """Returns the value of the attribute with the given name."""

    def getQNameByName(self, name):
        """Returns the qualified name of the attribute with the given name."""

    def __len__(self):
        """Returns the number of attributes in the list."""
        return len(self._values)

    def __getitem__(self, name):
        """Alias for getValue."""

    def __delitem__(self, name):
        """Removes the attribute with the given name."""

    def __contains__(self, name):
        """Alias for has_key."""

    def has_key(self, name):
        """Returns True if the attribute name is in the list,
        False otherwise."""

    def get(self, name, alternative=None):
        """Return the value associated with attribute name; if it is not
        available, then return the alternative."""

    def keys(self):
        """Returns a list of the names of all attribute in the list."""

    def items(self):
        """Return a list of (attribute_name, value) pairs."""

    def values(self):
        """Return a list of all attribute values."""
