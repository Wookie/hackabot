/* Minimal set of defines required for the Expat library */

/* This value is provided via the setup.py script */
/* 1234 = LIL_ENDIAN, 4321 = BIGENDIAN */
/* #undef BYTEORDER */

/* Python provides a memove() if there isn't a native implementation. */
/* Define to 1 if you have the `memmove' function. */
#define HAVE_MEMMOVE 1

/* Define to specify how much context to retain around the current parse
   point. */
#define XML_CONTEXT_BYTES 1024

/* Define to make parameter entity parsing functionality available. */
#define XML_DTD 1

/* Define to make XML Namespaces functionality available. */
#define XML_NS 1

/* On  Windows,  this  should  be  set  if  Expat is going to be linked 
   statically with the code that calls it; this is required to get all the
   right MSVC magic annotations correct. This is ignored on other platforms.
*/
#define XML_STATIC

/* Define to provide document information in UTF-16 rather than the
   default UTF-8. 
*/
/* #undef XML_UNICODE */
