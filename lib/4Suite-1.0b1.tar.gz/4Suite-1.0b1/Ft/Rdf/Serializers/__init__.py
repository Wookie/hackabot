
__doc__ = """
Serializers create a serialized representation from an RDF model, or populate
a model with statements from a serialized form.  Currently the only
built-in serializer for 4RDF handles a DOM form representing
the XML serialization from the RDF Model and syntax recommendation at
http://www.w3.org/TR/REC-rdf-syntax/.
"""

class RdfException(Exception):
    def __init__(self, errorCode, args=None):
        self.args = args or ()
        self.errorCode = errorCode
        Exception.__init__(self, g_errorMessages[errorCode]%self.args)


class Error:
    pass

