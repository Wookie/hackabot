########################################################################
#
# File Name:            BooleanExpressions
#
#
"""

Definition for the boolean expressions in versa

WWW: http://4suite.org/4XSLT        e-mail: support@4suite.org

Copyright (c) 1999-2001 Fourthought Inc, USA.   All Rights Reserved.
See  http://4suite.org/COPYRIGHT  for license and copyright information
"""

#No longer used at all

class BooleanExpression:
    """
    Base class for all boolean expressions
    """
    pass
    

class AnyExpression(BooleanExpression):
    """
    Return True what every the resource list contains
    """
    def filter(self, con):
        return 1
        
