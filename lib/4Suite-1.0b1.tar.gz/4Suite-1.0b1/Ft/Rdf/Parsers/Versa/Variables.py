########################################################################
#
# File Name:            Variables.py
#
#
"""
Versa variables
WWW: http://4suite.org/4RDF        e-mail: support@4suite.org

Copyright 2001-2002 Fourthought Inc, USA.
See  http://4suite.org/COPYRIGHT  for license and copyright information
"""

from Ft.Rdf import RDF_MS_BASE, RDF_SCHEMA_BASE, OBJECT_TYPE_RESOURCE, OBJECT_TYPE_UNKNOWN

import types
import DataTypes
from Ft.Xml.XPath import Util
#FIXME: Move to Versa exception
from Ft.Xml.XPath import RuntimeException


class VariableReference:
    """
    """ 
    def __init__(self,expr):
        self.expr = expr
        return

    def evaluate(self,con):
        expanded = Util.ExpandQName(self.expr, namespaces=con.nsMapping)
        try:
            return con.varBindings[expanded]
        except KeyError:
            raise RuntimeException(RuntimeException.UNDEFINED_VARIABLE,
                                   expanded[0], expanded[1])


