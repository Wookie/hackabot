########################################################################
# $Header: /var/local/cvsroot/4Suite/Ft/Rdf/Drivers/__init__.py,v 1.5 2005/03/03 09:40:38 mbrown Exp $
"""
RDF model drivers for various databases

Copyright 2005 Fourthought, Inc. (USA).
Detailed license and copyright information: http://4suite.org/COPYRIGHT
Project home, documentation, distributions: http://4suite.org/
"""

_modules = {}

def SetDriver(driverName):
    global g_dbDriver
    if driverName not in _modules:
        moduleName = 'Ft.Rdf.Drivers.%s' % driverName
        module = __import__(moduleName, {}, {}, ['InitializeModule'])
        module.InitializeModule()
        _modules[driverName] = module
    g_dbDriver = _modules[driverName]
    return

class PROPERTIES:
    #FIXME: Replace numbers with URIs
    OBJECT_TYPE_SUPPORTED = 1
