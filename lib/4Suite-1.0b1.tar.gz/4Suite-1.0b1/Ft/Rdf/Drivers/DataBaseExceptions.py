########################################################################
# $Header: /var/local/cvsroot/4Suite/Ft/Rdf/Drivers/DataBaseExceptions.py,v 1.2 2005/03/03 09:43:35 mbrown Exp $
"""
Exception classes used by database drivers

Copyright 2005 Fourthought, Inc. (USA).
Detailed license and copyright information: http://4suite.org/COPYRIGHT
Project home, documentation, distributions: http://4suite.org/
"""

class InvalidName:
    """
    currently a no-op
    """
    pass

class NoTransaction:
    """
    currently a no-op
    """
    pass
