public domain 16x16 icon set
based on the public domain icon set for Apache

Please notify Mike Brown <mike@skew.org>
if you have any updates to this set.

See also: http://hyperreal.org/~mike/pub/apache/
