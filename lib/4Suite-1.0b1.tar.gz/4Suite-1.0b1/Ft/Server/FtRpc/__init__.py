__doc__ = """

  An abstraction of our internal RPC protocol.  Currently this is implemented as sending pickled dictionaries
  across a socket.  We have plans to make this more cross language friendly

  """

from Ft.Server import FtServerBaseException
import MessageSource
from MessageSource import Error
class FtServerFtRpcException(FtServerBaseException):
    MessageSource = MessageSource

class CommandCodes:
    LOGIN = 1
    LOGOUT = 2
    RESOURCE_TYPE = 3
    REMOTE_METHOD = 4
    REMOTE_RDF = 5

class ResponseCodes:
    OK = 1
    GENERAL_ERROR = 2
    RESOURCE_TYPE = 3
    METHOD_RESULTS = 4
    FTSERVER_ERROR = 5
    RDF_RESULTS = 6
