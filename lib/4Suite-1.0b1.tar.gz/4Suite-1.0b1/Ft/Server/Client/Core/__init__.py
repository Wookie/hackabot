FTRPC_HOST = 'localhost'
FTRPC_PORT = 8803


def GetRepository(userName, passwdHash, host, port):
    from Ft.Server.FtRpc import Marshal

    conn, sysCon = Marshal.Connect(userName, passwdHash, host, port)

    import RepositoryClient
    repo = RepositoryClient.RepositoryClient(conn)

    return repo


