
import DocumentDefinitionClient
import XsltDocumentClient

class XsltDocumentDefinitionClient(DocumentDefinitionClient.DocumentDefinitionClient,
                                   XsltDocumentClient.XsltDocumentClient):

    pass
