


class ObjectCache:
    """
    A Object Cache that has the life span of a transaction
    """

    def __init__(self):

        self._cache = {}

    def getResource(self,path):
        return self._cache.get(path)

    def registerResource(self,path,obj):
        self._cache[path] = obj

    def unregisterResource(self,path):
        if self._cache.has_key(path): del self._cache[path]
