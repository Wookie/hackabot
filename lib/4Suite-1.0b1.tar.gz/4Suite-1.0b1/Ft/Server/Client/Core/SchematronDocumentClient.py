import XmlDocumentClient

class SchematronDocumentClient(XmlDocumentClient.XmlDocumentClient):
    """
    Provides implementation specific to a schematron document resource
    """
    pass

    
