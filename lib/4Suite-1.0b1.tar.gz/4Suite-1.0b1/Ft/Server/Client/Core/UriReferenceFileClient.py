import RawFileClient

class UriReferenceFileClient(RawFileClient.RawFileClient):
    """
    An Uri Reference File is a reference to a URI.  You are given read only access to it.
    MetaData about the Content is updated every time you call getContent
    """
    def getReference(self):
        raise NotImplementedError("getReference")

