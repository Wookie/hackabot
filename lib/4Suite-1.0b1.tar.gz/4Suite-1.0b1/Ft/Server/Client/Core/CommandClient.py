import XmlDocumentClient


class CommandClient(XmlDocumentClient.XmlDocumentClient):
    """
    A system command
    """
    pass

