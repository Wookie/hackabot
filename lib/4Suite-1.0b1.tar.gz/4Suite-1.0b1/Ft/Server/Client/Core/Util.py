import warnings

def SmartLogin(options=None):
    warnings.warn("You are using the deprecated SmartLogin Interface, Please use Ft.Server.Client.SmartLogin", DeprecationWarning, 2)
    from Ft.Server import Client
    return Client.SmartLogin(options)
