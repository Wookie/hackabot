from Ft.Server.FtRpc import Commands

class GroupableObjectMixin:

    def getGroups(self):
        """
        Returns all the groups that the user is a member of
        """
        data = Commands.RemoteMethodCommand(
            'getGroups', self._path,
            ()
            ).send(self._connection).results
        res = []
        parent = self.getParent()
        for path in data:
            res.append(parent.fetchResource(path))
        return res

