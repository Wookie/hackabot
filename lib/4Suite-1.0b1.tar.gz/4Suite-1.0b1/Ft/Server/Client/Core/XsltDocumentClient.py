import XmlDocumentClient

class XsltDocumentClient(XmlDocumentClient.XmlDocumentClient):
    """
    An Xslt Document
    """
    pass
