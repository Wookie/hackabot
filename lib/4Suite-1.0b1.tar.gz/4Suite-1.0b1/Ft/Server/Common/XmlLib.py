########################################################################
# $Header: /var/local/cvsroot/4Suite/Ft/Server/Common/XmlLib.py,v 1.13 2004/08/11 19:23:09 mbrown Exp $
"""
XML utility functions that are repository-specific

Copyright 2004 Fourthought, Inc. (USA).
Detailed license and copyright information: http://4suite.org/COPYRIGHT
Project home, documentation, distributions: http://4suite.org/
"""

def MakeString(st):
    #FIXME: Someone explain the point of this.
    """
    This is for internal calls only. It will make sure that internally
    created XML strings are "UTF-8 safe".

    It assumes the given string has no prolog. If the string is unicode,
    it will be UTF-8 encoded and a prolog with a UTF-8 encoding
    declaration will be added. If the string is a regular byte string,
    then a prolog with no encoding declaration will be added.
    """
    prologue = '<?xml version="1.0"'
    if isinstance(st, unicode):
        prologue += ' encoding="UTF-8"'
        st = st.encode('utf8')
    prologue += '?>\n'
    return prologue  + st

##def CompileSchematron(src, baseUri):
##    return ParseSchematron(src, baseUri).root


##def ParseStylesheet(baseObject, src):
##    from Ft.Server.Server.SCore import Readers
##    reader = Readers.StylesheetReader(baseObject)
##    comp = reader.fromString(src, refUri=baseObject.getAbsolutePath())
##    return comp


##def CompileStylesheet(baseObject, src):
##    return ParseStylesheet(baseObject, src).root


##def ParseXml(src, stripElements=None):
##    reader = FtssInputSource.NonvalidatingReader
##    comp = reader.fromString(src, stripElements=stripElements)
##    return comp

