"""
ACL constants
"""

SUPER_USER_GROUP_NAME='super-users'
WORLD_GROUP_NAME='world'
USERS_GROUP_NAME='users'
ANONYMOUS_USER_NAME='guest'

OWNER = 'owner'


ALLOWED=1
DENIED=0


READ_ACCESS='read'
WRITE_ACCESS='write'
EXECUTE_ACCESS='execute'
DELETE_ACCESS='delete'
CHANGE_OWNER_ACCESS='change owner'
CHANGE_PERMISSIONS_ACCESS='change permissions'
WRITE_USER_MODEL_ACCESS='write user model'
READ_METADATA_ACCESS = 'read metadata'
