########################################################################
#
# File Name:            Install
#
#
"""

Common libraries for install products into 4Suite

WWW: http://4suite.org/4XSLT        e-mail: support@4suite.org

Copyright (c) 1999-2001 Fourthought Inc, USA.   All Rights Reserved.
See  http://4suite.org/COPYRIGHT  for license and copyright information
"""

from Ft.Server import FTSERVER_NAMESPACE

PRODUCT_NAMESPACE="%s#product" % FTSERVER_NAMESPACE


