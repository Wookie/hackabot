########################################################################
#
# File Name:            FtpHandler.py
#
# Documentation:        http://docs.4suite.org/4SS/HttpListener.py.html
#
"""
FTP listener based on pyftpd
WWW: http://4suite.org         e-mail: support@4suite.org

Copyright (c) 2000-2001 Fourthought, Inc. USA.   All Rights Reserved.
See  http://4suite.org/COPYRIGHT  for license and copyright information
"""

from Ft.Server.Server import RequestHandler

from Session import Session

class FtpHandler(RequestHandler.RequestHandler):

    def handle(self):
        client_addr = (self.connection.remote_ip, self.connection.remote_port)
        session = Session(self.connection.rfile,
                          self.connection.wfile,
                          client_addr,
                          self.server)        
        session.loop()
        del session



